var loadAnalytics = document.createElement('script');
loadAnalytics.setAttribute('src','https://www.googletagmanager.com/gtag/js?id=UA-4370707-17');
//console.log(loadAnalytics);
document.querySelector('head').append(loadAnalytics);



window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            // gtag('js', new Date());

            // gtag('config', 'UA-4370707-17');

